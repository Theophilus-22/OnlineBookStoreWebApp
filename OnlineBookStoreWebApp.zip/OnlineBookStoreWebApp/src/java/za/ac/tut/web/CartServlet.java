package za.ac.tut.web;

import za.ac.tut.dao.BookDAO;
import za.ac.tut.model.Book;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.*;

public class CartServlet extends HttpServlet {

    private BookDAO bookDAO;

    @Override
    public void init() {
        bookDAO = new BookDAO();
    }

    @Override

protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

    String action = request.getParameter("action");
    HttpSession session = request.getSession();
    List<Book> cart = (List<Book>) session.getAttribute("cart");

    if (cart == null) {
        cart = new ArrayList<>();
    }

    if ("remove".equals(action)) {
        int bookId = Integer.parseInt(request.getParameter("bookId"));
        cart.removeIf(b -> b.getId() == bookId);
        session.setAttribute("cart", cart);
        response.sendRedirect("CartServlet.do?action=view");
    } else if ("buy".equals(action)) {
        // Simulate order processing
        session.removeAttribute("cart"); // Clear cart after purchase
        request.setAttribute("orderStatus", "success");
        request.setAttribute("cart", new ArrayList<Book>());
        RequestDispatcher dispatcher = request.getRequestDispatcher("cart.jsp");
        dispatcher.forward(request, response);
    } else {
        int bookId = Integer.parseInt(request.getParameter("bookId"));
        Book book = bookDAO.getBookById(bookId);
        cart.add(book);
        session.setAttribute("cart", cart);
        response.sendRedirect("BookServlet.do"); // Stay on book page
    }
}



    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");

        if ("view".equals(action)) {
            HttpSession session = request.getSession();
            List<Book> cart = (List<Book>) session.getAttribute("cart");

            if (cart == null) {
                cart = new ArrayList<>();
            }

            request.setAttribute("cart", cart);
            RequestDispatcher dispatcher = request.getRequestDispatcher("cart.jsp");
            dispatcher.forward(request, response);
        }
    }
}

