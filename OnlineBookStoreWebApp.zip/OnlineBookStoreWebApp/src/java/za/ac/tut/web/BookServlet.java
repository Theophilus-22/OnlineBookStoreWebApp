package za.ac.tut.web;

import java.io.IOException;
import java.util.List;
import javax.servlet.*;
import javax.servlet.http.*;
import za.ac.tut.dao.BookDAO;
import za.ac.tut.model.Book;

public class BookServlet extends HttpServlet {

    private BookDAO bookDAO;

    @Override
    public void init() {
        bookDAO = new BookDAO();
    }

    @Override
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

        String category = request.getParameter("category");
        List<Book> books;

     if (category != null && !category.trim().isEmpty()) {
        books = bookDAO.getBooksByCategory(category);
     } else {
        books = bookDAO.getAllBooks();
     }

     request.setAttribute("books", books);
     RequestDispatcher dispatcher = request.getRequestDispatcher("bookList.jsp");
     dispatcher.forward(request, response);
     
    }

}


