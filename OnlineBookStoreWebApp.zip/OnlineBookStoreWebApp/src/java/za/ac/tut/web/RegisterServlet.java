package za.ac.tut.web;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class RegisterServlet extends HttpServlet {

    private String jdbcURL = "jdbc:derby://localhost:1527/OnlineBookStore";
    private String jdbcUsername = "bookstore";
    private String jdbcPassword = "123";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String gender = request.getParameter("gender");

        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            Connection conn = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);

            // Check if user already exists
            PreparedStatement check = conn.prepareStatement("SELECT * FROM users WHERE username=?");
            check.setString(1, username);
            ResultSet rs = check.executeQuery();

            if (rs.next()) {
                // Username already taken
                response.sendRedirect("register.jsp?error=1");
            } else {
                // Insert user data into database
                PreparedStatement insert = conn.prepareStatement(
                        "INSERT INTO users (username, password, email, phone, gender) VALUES (?, ?, ?, ?, ?)"
                );
                insert.setString(1, username);
                insert.setString(2, password);
                insert.setString(3, email);
                insert.setString(4, phone);
                insert.setString(5, gender);

                insert.executeUpdate();
                conn.close();

                // Redirect to login with a success message
                response.sendRedirect("login.jsp?registered=1");
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("register.jsp?error=1");
        }
    }
}


