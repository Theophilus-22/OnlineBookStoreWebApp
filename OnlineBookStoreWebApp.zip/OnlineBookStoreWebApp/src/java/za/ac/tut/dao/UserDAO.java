package za.ac.tut.dao;

import java.security.MessageDigest;
import java.sql.*;
import za.ac.tut.model.User;

public class UserDAO {
    
    private Connection getConnection() throws SQLException {
        String url = "jdbc:derby://localhost:1527/OnlineBookStore";
        String user = "bookstore";
        String password = "123";
        return DriverManager.getConnection(url, user, password);
    }

    public User validateUser(String email, String password) {
    User user = null;
    String sql = "SELECT * FROM users WHERE email = ? AND password = ?";

    try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
        ps.setString(1, email);
        ps.setString(2, password);

        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            user = new User();
            user.setId(rs.getInt("id"));
            user.setUsername(rs.getString("username")); // make sure this matches your DB column
            user.setPassword(rs.getString("password"));
            user.setEmail(rs.getString("email"));
            user.setPhone(rs.getString("phone"));
            user.setGender(rs.getString("gender"));
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return user;
}




    private String hashPassword(String password) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] hashed = md.digest(password.getBytes("UTF-8"));

        StringBuilder hexString = new StringBuilder();
        for (byte b : hashed) {
            String hex = Integer.toHexString(0xff & b);
            if (hex.length() == 1) hexString.append('0');
            hexString.append(hex);
        }

        return hexString.toString();
    }
}

