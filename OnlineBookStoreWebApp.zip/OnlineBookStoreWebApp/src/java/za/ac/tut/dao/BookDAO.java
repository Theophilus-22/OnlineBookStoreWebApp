/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import za.ac.tut.model.Book;

/**
 *
 * @author USER
 */
public class BookDAO {
    
    private String jdbcURL = "jdbc:derby://localhost:1527/OnlineBookStore";
    private String jdbcUsername = "bookstore";
    private String jdbcPassword = "123";

    private static final String SELECT_ALL_BOOKS = "SELECT * FROM books";

    public List<Book> getAllBooks() {
        List<Book> books = new ArrayList<>();

    try {
        Class.forName("org.apache.derby.jdbc.ClientDriver");
        Connection conn = DriverManager.getConnection("jdbc:derby://localhost:1527/OnlineBookStore", "bookstore", "123");

        String sql = "SELECT * FROM books";
        PreparedStatement ps = conn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            Book book = new Book();
            book.setId(rs.getInt("id"));
            book.setTitle(rs.getString("title"));
            book.setAuthor(rs.getString("author"));
            book.setPrice(rs.getDouble("price"));
            books.add(book);
        }

        conn.close();
    } catch (Exception e) {
        e.printStackTrace();
    }

    return books;
    }
    
    public List<Book> getBooksByCategory(String category) {
    List<Book> books = new ArrayList<>();
    try {
        Class.forName("org.apache.derby.jdbc.ClientDriver");
        Connection conn = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
        String sql = "SELECT * FROM books WHERE LOWER(category) = LOWER(?)";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, category);
        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            Book book = new Book();
            book.setId(rs.getInt("id"));
            book.setTitle(rs.getString("title"));
            book.setAuthor(rs.getString("author"));
            book.setPrice(rs.getDouble("price"));
            books.add(book);
        }

        conn.close();
    } catch (Exception e) {
        e.printStackTrace();
    }

    return books;
}

    
    public Book getBookById(int id) {
    try {
        Class.forName("org.apache.derby.jdbc.ClientDriver");
        Connection conn = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
        PreparedStatement stmt = conn.prepareStatement("SELECT * FROM books WHERE id = ?");
        stmt.setInt(1, id);
        ResultSet rs = stmt.executeQuery();

        if (rs.next()) {
            return new Book(
                rs.getInt("id"),
                rs.getString("title"),
                rs.getString("author"),
                rs.getDouble("price")
            );
        }
        conn.close();
    } catch (Exception e) {
        e.printStackTrace();
    }
    return null;
}
    
}
